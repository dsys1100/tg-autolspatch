package ru.dsys1100.TGnoBottomStuff;

import android.content.Context;
import android.view.View;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class TGModule implements IXposedHookLoadPackage {

    private static final String TAG = "TGnoBottomStuff";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p)
            throws Throwable {

        try {
            XposedHelpers.findClass(
                    "org.telegram.ui.DialogsActivity",
                    p.classLoader
            );
        } catch (Throwable e) {
            return;
        }

        hookTabs(p);
        hookDialogs(p);
        hookFloatingButtons(p);
    }

    private void hookTabs(XC_LoadPackage.LoadPackageParam p) {
        try {
            Class<?> controller = XposedHelpers.findClass(
                    "org.telegram.ui.MainTabsActivity$MainTabsActivityControllerImpl",
                    p.classLoader
            );

            XposedHelpers.findAndHookMethod(
                    controller,
                    "setTabsVisible",
                    boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                Object activity =
                                        XposedHelpers.getObjectField(
                                                param.thisObject,
                                                "this$0"
                                        );

                                Object animator =
                                        XposedHelpers.getObjectField(
                                                activity,
                                                "animatorTabsVisible"
                                        );

                                XposedHelpers.callMethod(
                                        animator,
                                        "setValue",
                                        false,
                                        false
                                );

                                param.setResult(null);
                            } catch (Throwable e) {
                                XposedBridge.log(TAG + ": tabs " + e);
                                param.setResult(null);
                            }
                        }
                    }
            );
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": tabs hook " + e);
        }
    }

    private void hookDialogs(XC_LoadPackage.LoadPackageParam p) {
        try {
            Class<?> dialogs = XposedHelpers.findClass(
                    "org.telegram.ui.DialogsActivity",
                    p.classLoader
            );

            XposedHelpers.findAndHookMethod(
                    dialogs,
                    "createView",
                    Context.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            hideFab(param.thisObject, "floatingButton3");
                            hideFab(param.thisObject, "floatingButtonStories");
                        }
                    }
            );
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": dialogs hook " + e);
        }
    }

    private void hideFab(Object fragment, String field) {
        try {
            Object value = XposedHelpers.getObjectField(fragment, field);

            if (value instanceof View) {
                View view = (View) value;

                XposedHelpers.setAdditionalInstanceField(
                        view,
                        TAG,
                        Boolean.TRUE
                );

                view.setAlpha(0f);
                view.setScaleX(0.4f);
                view.setScaleY(0.4f);
                view.setVisibility(View.GONE);
            }
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": hide " + field + " " + e);
        }
    }

    private void hookFloatingButtons(
            XC_LoadPackage.LoadPackageParam p) {

        try {
            Class<?> button = XposedHelpers.findClass(
                    "org.telegram.ui.Components.FragmentFloatingButton",
                    p.classLoader
            );

            XposedHelpers.findAndHookMethod(
                    button,
                    "setAnimatedVisibility",
                    View.class,
                    float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(
                                MethodHookParam param) {

                            View view = (View) param.args[0];

                            if (view != null
                                    && Boolean.TRUE.equals(
                                    XposedHelpers.getAdditionalInstanceField(
                                            view,
                                            TAG
                                    ))) {
                                param.args[1] = 0f;
                            }
                        }
                    }
            );
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": floating button hook " + e);
        }
    }
}